ssh-add -c (Linux) or ssh-add -k (Mac) ec2-user@public-IP-address 
ssh -A ec2-user@private-IP-address