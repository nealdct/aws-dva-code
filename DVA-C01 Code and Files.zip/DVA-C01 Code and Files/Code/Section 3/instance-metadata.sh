curl http://169.254.169.254/latest/meta-data/

wget https://s3.amazonaws.com/ec2metadata/ec2-metadata chmod u+x ec2-metadata
ec2-metadata -help